<?php
// Tampilkan error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include koneksi database
include "koneksi.php";

// Cek apakah koneksi berhasil
if (!isset($koneksi)) {
    die("Error: Koneksi database tidak ditemukan. Pastikan koneksi.php sudah benar.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Ambil data dari form
    $no_resi = $_POST['no_resi'];
    $lokasi = $_POST['lokasi_penerima'];
    $id_penerima = $_POST['id_penerima'];
    $gudang = $_POST['gudang'];
    $status = $_POST['status_pengiriman'];
    
    // Tampilkan data yang diterima
    echo "<h3>Data yang diterima:</h3>";
    echo "No Resi: $no_resi<br>";
    echo "Lokasi: $lokasi<br>";
    echo "ID Penerima: $id_penerima<br>";
    echo "Gudang: $gudang<br>";
    echo "Status: $status<br><br>";
    
    // Gunakan Prepared Statement
    $query = "INSERT INTO sortir (no_resi, lokasi_penerima, id_penerima, gudang, status_pengiriman) 
              VALUES (?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($koneksi, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssss", $no_resi, $lokasi, $id_penerima, $gudang, $status);
        
        if (mysqli_stmt_execute($stmt)) {
            echo "<h3 style='color:green;'>✓ Data berhasil disimpan!</h3>";
            echo "<a href='index.php'>Kembali ke Halaman Utama</a>";
        } else {
            echo "<h3 style='color:red;'>✗ Gagal menyimpan data</h3>";
            echo "Error: " . mysqli_stmt_error($stmt);
        }
        
        mysqli_stmt_close($stmt);
    } else {
        echo "<h3 style='color:red;'>✗ Gagal prepare statement</h3>";
        echo "Error: " . mysqli_error($koneksi);
    }
    
    mysqli_close($koneksi);
    
} else {
    header("Location: tambah.php");
    exit;
}
?>